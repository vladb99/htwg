#!/bin/sh
rm -rf *.aux *.bbl *.blg *.log *.out *.bak *.dvi *.lof *.lol *.lot *.toc *.synctex.gz preface/*.aux preface/*.log appendix/*.aux appendix/*.log media/matlab/HISTOGRAM/*eps-converted-to*
